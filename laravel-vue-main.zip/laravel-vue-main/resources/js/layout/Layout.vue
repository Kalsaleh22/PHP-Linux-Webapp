<template>
    <nav-bar />
    <router-view />
    <footer-content />
</template>
