<template>
    <carousel-component />
    <showall-products />
</template>
