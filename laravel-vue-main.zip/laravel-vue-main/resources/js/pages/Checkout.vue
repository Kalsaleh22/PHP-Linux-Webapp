<template>
  <h1 class="h-10 p-6 text-3xl font-bold text-center">Checkout</h1>
  <order-checkout />
</template>
