<template>
  <div>Show all categories</div>
</template>

<script setup>

</script>
